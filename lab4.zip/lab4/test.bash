#!/bin/bash

# Проверка наличия `dialog`
if ! command -v dialog &> /dev/null; then
    echo "dialog не установлен. Установите его для работы скрипта."
    exit 1
fi

DIALOG=dialog

# Предопределенный 

function choose_action {
    local ACTION=$($DIALOG --clear --stdout --title "Главное меню" \
        --menu "Выберите действие:" 15 50 4 \
        1 "Поиск студентов с наибольшими ошибками" \
        2 "Найти занятия с максимальной посещаемостью" \
        3 "Вычислить среднюю посещаемость" \
        4 "Выход")

    case $ACTION in
        1) bad_student ;;
        2) max_attendance ;;
        3) average_attendance ;;
        4) clear; echo "Выход из программы."; exit 0 ;;
        *) clear; echo "Неверный выбор."; choose_action ;;
    esac
}

function bad_student {
    local SUBJECT=$($DIALOG --clear --stdout --title "Выбор предмета" \
        --menu "Выберите предмет:" 10 40 2 \
        1 "Пивоварение" \
        2 "Уфология")

    case $SUBJECT in
        1) SUBJECT="Пивоварение"; total_questions=25 ;;
        2) SUBJECT="Уфология"; total_questions=5 ;;
        *) $DIALOG --msgbox "Неверный выбор предмета!" 10 30; return ;;
    esac

    local YEAR=$($DIALOG --inputbox "Введите год:" 10 30 --stdout)
    [[ -z "$YEAR" ]] && return

    # Встроенный выбор группы
    local GROUP=$($DIALOG --clear --stdout --title "Выбор группы" \
        --radiolist "Выберите группу:" 20 50 16 \
        "A-06-04" "" off \
        "A-06-05" "" off \
        "A-06-06" "" off \
        "A-06-07" "" off \
        "A-06-08" "" off \
        "A-06-09" "" off \
        "A-06-10" "" off \
        "A-06-11" "" off \
        "A-06-12" "" off \
        "A-06-13" "" off \
        "A-06-14" "" off \
        "A-06-15" "" off \
        "A-06-16" "" off \
        "A-06-17" "" off \
        "A-06-18" "" off \
        "A-06-19" "" off \
        "A-06-20" "" off \
        "A-06-21" "" off)
    
    # Проверка выбора группы
    if [[ -z "$GROUP" ]]; then
        $DIALOG --msgbox "Выбор группы не сделан!" 10 30
        return
    fi

    echo "Анализируем студентов группы $GROUP по предмету $SUBJECT за $YEAR год."
    # Здесь вызов функции анализа данных
}


function max_attendance {
    local SUBJECT=$($DIALOG --inputbox "Введите предмет:" 10 30 --stdout)
    [[ -z "$SUBJECT" ]] && return

    local GROUP=$(choose_group)
    [[ $? -ne 0 ]] && return

    echo "Анализ посещаемости для группы $GROUP по предмету $SUBJECT."
    # Здесь вызов функции анализа данных
}

function average_attendance {
    local SUBJECT=$($DIALOG --inputbox "Введите предмет:" 10 30 --stdout)
    [[ -z "$SUBJECT" ]] && return

    echo "Введите несколько групп через пробел:"
    local GROUPS_CHOICE=$($DIALOG --stdout --inputbox "Введите группы (через пробел):" 10 50)

    [[ -z "$GROUPS_CHOICE" ]] && return

    echo "Анализируем среднюю посещаемость для групп: $GROUPS_CHOICE по предмету $SUBJECT."
    # Здесь вызов функции анализа данных
}

choose_action

